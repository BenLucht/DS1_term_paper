from sklearn.cluster import SpectralClustering

def cluster_spectral(input):
  '''
  inputs:   info on the parameter
  '''

  return None