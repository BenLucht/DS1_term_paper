from sklearn.cluster import AffinityPropagation

def cluster_affinity(input):
  '''
  inputs:   info on the parameter
  '''

  return None